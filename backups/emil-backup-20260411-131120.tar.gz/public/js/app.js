import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js';
import { 
    getAuth, 
    signInWithEmailAndPassword, 
    onAuthStateChanged,
    signOut 
} from 'https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js';
import { 
    getFirestore, 
    collection, 
    addDoc, 
    getDocs, 
    updateDoc,
    deleteDoc,
    doc,
    setDoc,
    writeBatch,
    query,
    where,
    orderBy,
    onSnapshot,
    serverTimestamp
} from 'https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js';
import { 
    getFunctions, 
    httpsCallable 
} from 'https://www.gstatic.com/firebasejs/10.7.1/firebase-functions.js';

const firebaseConfig = {
    apiKey: "AIzaSyBR74UHgCmayg_0WKmoCD_lqACU2GRu3Ak",
    authDomain: "global-email-script.firebaseapp.com",
    projectId: "global-email-script",
    storageBucket: "global-email-script.firebasestorage.app",
    messagingSenderId: "868325182303",
    appId: "1:868325182303:web:936828c9461c3f9839c4ea"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);
const functions = getFunctions(app);

const loginScreen = document.getElementById('loginScreen');
const mainApp = document.getElementById('mainApp');
const loginForm = document.getElementById('loginForm');
const loginError = document.getElementById('loginError');
const logoutBtn = document.getElementById('logoutBtn');

const dashboardTab = document.getElementById('dashboardTab');
const settingsTab = document.getElementById('settingsTab');
const radyTab = document.getElementById('radyTab');
const blacklistTab = document.getElementById('blacklistTab');
const dashboardSection = document.getElementById('dashboardSection');
const settingsSection = document.getElementById('settingsSection');
const radySection = document.getElementById('radySection');
const blacklistSection = document.getElementById('blacklistSection');

const statSentToday = document.getElementById('statSentToday');
const statRemaining = document.getElementById('statRemaining');
const statErrors = document.getElementById('statErrors');
const statTotal = document.getElementById('statTotal');
const dailyLimit = document.getElementById('dailyLimit');

const contactsTable = document.getElementById('contactsTable');
const addContactForm = document.getElementById('addContactForm');
const csvFile = document.getElementById('csvFile');
const csvFileName = document.getElementById('csvFileName');
const importBtn = document.getElementById('importBtn');
const refreshContacts = document.getElementById('refreshContacts');



const smtpForm = document.getElementById('smtpForm');
const settingsSuccess = document.getElementById('settingsSuccess');

let currentUser = null;

onAuthStateChanged(auth, (user) => {
    if (user) {
        currentUser = user;
        loginScreen.classList.add('hidden');
        mainApp.classList.remove('hidden');
        loadDashboard();
        loadContacts();
        loadSettings();
    } else {
        currentUser = null;
        loginScreen.classList.remove('hidden');
        mainApp.classList.add('hidden');
    }
});

loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;
    
    try {
        await signInWithEmailAndPassword(auth, email, password);
        loginError.classList.add('hidden');
    } catch (error) {
        loginError.textContent = 'Nesprávne prihlasovacie údaje';
        loginError.classList.remove('hidden');
    }
});

logoutBtn.addEventListener('click', async () => {
    await signOut(auth);
});

// Campaign control
const startCampaignBtn = document.getElementById('startCampaignBtn');
const stopCampaignBtn = document.getElementById('stopCampaignBtn');
const campaignStatusText = document.getElementById('campaignStatusText');
const campaignMessage = document.getElementById('campaignMessage');

// Load campaign status
async function loadCampaignStatus() {
    try {
        const getCampaignStatus = httpsCallable(functions, 'getCampaignStatus');
        const result = await getCampaignStatus();
        const status = result.data;
        
        updateCampaignUI(status.active);
    } catch (error) {
        console.error('Error loading campaign status:', error);
        // If error, assume campaign is not active (show as paused)
        updateCampaignUI(false);
    }
}

function updateCampaignUI(active) {
    if (active) {
        campaignStatusText.innerHTML = '<span class="text-green-300 font-bold">🟢 AKTÍVNA</span>';
        startCampaignBtn.classList.add('hidden');
        stopCampaignBtn.classList.remove('hidden');
    } else {
        campaignStatusText.innerHTML = '<span class="text-yellow-300 font-bold">⏸️ POZASTAVENÁ</span>';
        startCampaignBtn.classList.remove('hidden');
        stopCampaignBtn.classList.add('hidden');
    }
}

startCampaignBtn.addEventListener('click', async () => {
    if (!confirm('Naozaj chcete spustiť kampaň? Emaily sa začnú automaticky odosielať podľa nastaveného schedulera.')) {
        return;
    }
    
    startCampaignBtn.disabled = true;
    startCampaignBtn.innerHTML = '<div class="loader"></div><span>Spúšťam...</span>';
    
    try {
        const toggleCampaign = httpsCallable(functions, 'toggleCampaign');
        const result = await toggleCampaign({ action: 'start' });
        const data = result.data;
        
        updateCampaignUI(true);
        
        campaignMessage.className = 'mt-4 p-3 rounded-lg text-sm bg-green-500/90 text-white';
        campaignMessage.innerHTML = `
            <div class="flex items-center space-x-2">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                </svg>
                <span><strong>Úspech!</strong> ${data.message}</span>
            </div>
        `;
        campaignMessage.classList.remove('hidden');
        
        setTimeout(() => campaignMessage.classList.add('hidden'), 5000);
        
    } catch (error) {
        console.error('Error starting campaign:', error);
        showCampaignError(error.message);
    } finally {
        startCampaignBtn.disabled = false;
        startCampaignBtn.innerHTML = `
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z"></path>
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
            </svg>
            <span>Začať kampaň</span>
        `;
    }
});

stopCampaignBtn.addEventListener('click', async () => {
    if (!confirm('Naozaj chcete zastaviť kampaň? Žiadne emaily sa nebudú odosielať, kým kampaň znova nespustíte.')) {
        return;
    }
    
    stopCampaignBtn.disabled = true;
    stopCampaignBtn.innerHTML = '<div class="loader"></div><span>Zastavujem...</span>';
    
    try {
        const toggleCampaign = httpsCallable(functions, 'toggleCampaign');
        const result = await toggleCampaign({ action: 'stop' });
        const data = result.data;
        
        updateCampaignUI(false);
        
        campaignMessage.className = 'mt-4 p-3 rounded-lg text-sm bg-yellow-500/90 text-white';
        campaignMessage.innerHTML = `
            <div class="flex items-center space-x-2">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                </svg>
                <span><strong>Zastavené!</strong> ${data.message}</span>
            </div>
        `;
        campaignMessage.classList.remove('hidden');
        
        setTimeout(() => campaignMessage.classList.add('hidden'), 5000);
        
    } catch (error) {
        console.error('Error stopping campaign:', error);
        showCampaignError(error.message);
    } finally {
        stopCampaignBtn.disabled = false;
        stopCampaignBtn.innerHTML = `
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 10a1 1 0 011-1h4a1 1 0 011 1v4a1 1 0 01-1 1h-4a1 1 0 01-1-1v-4z"></path>
            </svg>
            <span>Zastaviť kampaň</span>
        `;
    }
});

function showCampaignError(message) {
    campaignMessage.className = 'mt-4 p-3 rounded-lg text-sm bg-red-500/90 text-white';
    campaignMessage.innerHTML = `
        <div class="flex items-center space-x-2">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
            </svg>
            <span><strong>Chyba:</strong> ${message}</span>
        </div>
    `;
    campaignMessage.classList.remove('hidden');
    setTimeout(() => campaignMessage.classList.add('hidden'), 5000);
}

dashboardTab.addEventListener('click', () => {
    switchTab('dashboard');
});

settingsTab.addEventListener('click', () => {
    switchTab('settings');
});

radyTab.addEventListener('click', () => {
    switchTab('rady');
});

blacklistTab.addEventListener('click', () => {
    switchTab('blacklist');
});

window.switchTab = function switchTab(tab) {
    document.querySelectorAll('.nav-tab').forEach(btn => {
        btn.classList.remove('border-b-2', 'border-primary', 'text-gray-900');
        btn.classList.add('text-gray-500');
    });

    dashboardSection.classList.add('hidden');
    settingsSection.classList.add('hidden');
    radySection.classList.add('hidden');
    blacklistSection.classList.add('hidden');

    if (tab === 'dashboard') {
        dashboardTab.classList.add('border-b-2', 'border-primary', 'text-gray-900');
        dashboardTab.classList.remove('text-gray-500');
        dashboardSection.classList.remove('hidden');
        loadDashboard();
    } else if (tab === 'settings') {
        settingsTab.classList.add('border-b-2', 'border-primary', 'text-gray-900');
        settingsTab.classList.remove('text-gray-500');
        settingsSection.classList.remove('hidden');
    } else if (tab === 'rady') {
        radyTab.classList.add('border-b-2', 'border-primary', 'text-gray-900');
        radyTab.classList.remove('text-gray-500');
        radySection.classList.remove('hidden');
    } else if (tab === 'blacklist') {
        blacklistTab.classList.add('border-b-2', 'border-primary', 'text-gray-900');
        blacklistTab.classList.remove('text-gray-500');
        blacklistSection.classList.remove('hidden');
        loadBlacklist();
    }
}

async function loadDashboard() {
    try {
        const getDashboardStats = httpsCallable(functions, 'getDashboardStats');
        const result = await getDashboardStats();
        const stats = result.data;
        
        statSentToday.textContent = stats.sentToday;
        statRemaining.textContent = stats.remainingContacts;
        statErrors.textContent = stats.errorsToday;
        statTotal.textContent = stats.totalContacts;
        dailyLimit.textContent = stats.dailyLimit;
        
        // Load campaign status
        await loadCampaignStatus();
        
        // Load total emails sent
        await loadTotalEmailsSent();

        // Load success rate
        await loadSuccessRate();
        
        // Load 7-day chart
        await load7DayChart();
    } catch (error) {
        console.error('Error loading stats:', error);
    }
}

async function loadTotalEmailsSent() {
    try {
        const sentContactsSnapshot = await getDocs(
            query(collection(db, 'contacts'), where('sent', '==', true))
        );
        const totalSent = sentContactsSnapshot.size;
        document.getElementById('totalEmailsSent').textContent = totalSent;
    } catch (error) {
        console.error('Error loading total emails:', error);
    }
}

async function loadSuccessRate() {
    try {
        const logsSnap = await getDocs(collection(db, 'email_logs'));
        const total = logsSnap.size;
        const successful = logsSnap.docs.filter(d => d.data().success === true).length;
        const el = document.getElementById('statSuccessRate');
        if (total === 0) {
            el.textContent = '—';
        } else {
            const pct = Math.round((successful / total) * 100);
            el.textContent = `${pct}%`;
            el.className = `text-3xl font-bold mt-2 ${pct >= 90 ? 'text-green-600' : pct >= 70 ? 'text-yellow-600' : 'text-red-600'}`;
        }
    } catch (error) {
        console.error('Error loading success rate:', error);
    }
}

async function load7DayChart() {
    try {
        const days = [];
        const today = new Date();
        
        // Get last 7 days
        for (let i = 6; i >= 0; i--) {
            const date = new Date(today);
            date.setDate(date.getDate() - i);
            const dateStr = date.toISOString().split('T')[0];
            days.push({ date: dateStr, count: 0, label: date.getDate() });
        }
        
        // Get email logs
        const logsSnapshot = await getDocs(collection(db, 'email_logs'));
        logsSnapshot.forEach((doc) => {
            const data = doc.data();
            if (data.success && data.date) {
                const dayIndex = days.findIndex(d => d.date === data.date);
                if (dayIndex !== -1) {
                    days[dayIndex].count++;
                }
            }
        });
        
        // Find max for scaling
        const maxCount = Math.max(...days.map(d => d.count), 5);
        
        // Update chart bars
        days.forEach((day, index) => {
            const bar = document.getElementById(`day${index}`);
            const label = document.getElementById(`day${index}Label`);
            const height = maxCount > 0 ? (day.count / maxCount) * 100 : 0;
            
            if (bar) {
                bar.style.height = height + '%';
                bar.title = `${day.count} emailov`;
            }
            
            if (label && index !== 6) {
                label.textContent = day.label;
            }
        });
    } catch (error) {
        console.error('Error loading 7-day chart:', error);
    }
}

async function loadContacts() {
    try {
        const q = query(collection(db, 'contacts'), orderBy('createdAt', 'desc'));
        
        onSnapshot(q, (snapshot) => {
            contactsTable.innerHTML = '';

            const total = snapshot.size;
            const remaining = snapshot.docs.filter(d => !d.data().sent).length;
            statTotal.textContent = total;
            statRemaining.textContent = remaining;

            if (snapshot.empty) {
                contactsTable.innerHTML = `
                    <tr>
                        <td colspan="5" class="px-6 py-8 text-center text-gray-500">
                            Žiadne kontakty. Pridajte nový kontakt alebo importujte CSV.
                        </td>
                    </tr>
                `;
                return;
            }
            
            snapshot.forEach((docSnap) => {
                const contact = docSnap.data();
                const row = document.createElement('tr');
                row.className = 'hover:bg-gray-50 transition';
                
                const statusBadge = contact.sent 
                    ? '<span class="px-2 py-1 bg-green-100 text-green-700 text-xs rounded-full font-medium">Odoslané</span>'
                    : '<span class="px-2 py-1 bg-yellow-100 text-yellow-700 text-xs rounded-full font-medium">Čaká</span>';
                
                const sentDate = contact.sentAt 
                    ? new Date(contact.sentAt.toDate()).toLocaleString('sk-SK')
                    : '-';
                
                row.innerHTML = `
                    <td class="px-6 py-4 text-sm text-gray-700">${contact.name}</td>
                    <td class="px-6 py-4 text-sm text-gray-700">${contact.email}</td>
                    <td class="px-6 py-4 text-sm">${statusBadge}</td>
                    <td class="px-6 py-4 text-sm text-gray-600">${sentDate}</td>
                    <td class="px-6 py-4 text-sm">
                        <div class="flex items-center gap-2">
                            <button onclick="blacklistContact('${docSnap.id}', '${contact.email}')"
                                    title="Pridať na blacklist a odstrániť z fronty"
                                    class="px-2.5 py-1 text-xs font-medium rounded-lg border border-orange-300 text-orange-600 hover:bg-orange-50 transition">
                                🚫 Blokovať
                            </button>
                            <button onclick="deleteContact('${docSnap.id}')"
                                    title="Odstrániť z fronty"
                                    class="px-2.5 py-1 text-xs font-medium rounded-lg border border-red-200 text-red-500 hover:bg-red-50 transition">
                                Zmazať
                            </button>
                        </div>
                    </td>
                `;
                contactsTable.appendChild(row);
            });
            
            loadDashboard();
        });
    } catch (error) {
        console.error('Error loading contacts:', error);
    }
}

window.deleteContact = async (contactId) => {
    if (confirm('Naozaj chcete zmazať tento kontakt?')) {
        try {
            await deleteDoc(doc(db, 'contacts', contactId));
        } catch (error) {
            console.error('Error deleting contact:', error);
            alert('Chyba pri mazaní kontaktu');
        }
    }
};

window.blacklistContact = async (contactId, email) => {
    if (!confirm(`Pridať ${email} na blacklist a zmazať z kontaktov?`)) return;
    try {
        const emailLower = email.toLowerCase().trim();
        // WriteBatch = atomická operácia — blacklist + zmazanie v jedinom write
        // Scheduler nemôže stihnúť odoslať email medzi týmito dvoma krokmi
        const batch = writeBatch(db);
        batch.set(doc(db, 'blacklist', emailLower), {
            value: emailLower,
            type: 'email',
            reason: 'Manuálne',
            addedAt: serverTimestamp(),
        });
        batch.delete(doc(db, 'contacts', contactId));
        await batch.commit();
    } catch (error) {
        console.error('Blacklist contact error:', error);
        alert('Chyba pri pridávaní na blacklist.');
    }
};

addContactForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const name = document.getElementById('contactName').value;
    const email = document.getElementById('contactEmail').value.toLowerCase().trim();

    if (isToxicDomain(email)) {
        alert(`⚠️ Tento email nemožno pridať.\n\n"${email}" patrí k jednorazovým/dočasným emailovým službám. Za takýmito adresami nestojí reálna osoba.`);
        return;
    }

    try {
        // Deduplikácia — skontroluj či email už existuje
        const existing = await getDocs(query(collection(db, 'contacts'), where('email', '==', email)));
        if (!existing.empty) {
            alert(`⚠️ Kontakt "${email}" už je v zozname.`);
            return;
        }

        await addDoc(collection(db, 'contacts'), {
            email,
            name,
            sent: false,
            createdAt: serverTimestamp()
        });
        
        document.getElementById('contactName').value = '';
        document.getElementById('contactEmail').value = '';
        
        alert('Kontakt pridaný!');
    } catch (error) {
        console.error('Error adding contact:', error);
        alert('Chyba pri pridávaní kontaktu');
    }
});

csvFile.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (file) {
        csvFileName.textContent = `Vybraný súbor: ${file.name}`;
    }
});

importBtn.addEventListener('click', async () => {
    const file = csvFile.files[0];
    if (!file) {
        alert('Vyberte CSV súbor');
        return;
    }
    
    try {
        const text = await file.text();
        const lines = text.split('\n').filter(line => line.trim());
        
        // Načítaj existujúce emaily pre rýchlu deduplikáciu
        const existingSnap = await getDocs(collection(db, 'contacts'));
        const existingEmails = new Set(existingSnap.docs.map(d => (d.data().email || '').toLowerCase().trim()));

        let imported = 0;
        let skippedToxic = 0;
        let skippedDupe = 0;
        for (let i = 1; i < lines.length; i++) {
            const [name, email] = lines[i].split(',').map(s => s.trim());
            if (email && name) {
                const emailLower = email.toLowerCase().trim();
                if (isToxicDomain(emailLower)) {
                    skippedToxic++;
                    continue;
                }
                if (existingEmails.has(emailLower)) {
                    skippedDupe++;
                    continue;
                }
                await addDoc(collection(db, 'contacts'), {
                    email: emailLower,
                    name,
                    sent: false,
                    createdAt: serverTimestamp()
                });
                existingEmails.add(emailLower);
                imported++;
            }
        }

        const msgs = [`Importovaných ${imported} kontaktov.`];
        if (skippedDupe > 0) msgs.push(`⚠️ Preskočených ${skippedDupe} duplicitných emailov.`);
        if (skippedToxic > 0) msgs.push(`🚫 Preskočených ${skippedToxic} jednorazových emailov.`);
        alert(msgs.join('\n'));
        csvFile.value = '';
        csvFileName.textContent = '';
    } catch (error) {
        console.error('Error importing CSV:', error);
        alert('Chyba pri importovaní CSV');
    }
});

refreshContacts.addEventListener('click', () => {
    loadContacts();
    loadDashboard();
});

async function loadSettings() {
    try {
        const smtpDoc = await getDocs(collection(db, 'settings'));
        const settingsData = smtpDoc.docs.find(doc => doc.id === 'smtp');
        
        if (settingsData) {
            const data = settingsData.data();
            document.getElementById('smtpHost').value = data.host || '';
            document.getElementById('smtpPort').value = data.port || '';
            document.getElementById('smtpUser').value = data.user || '';
            document.getElementById('smtpPass').value = data.pass || '';
        }
        
        const emailDoc = smtpDoc.docs.find(doc => doc.id === 'email');
        if (emailDoc) {
            const data = emailDoc.data();
            if (data.subjects) {
                document.getElementById('emailSubjects').value = data.subjects.join('\n');
            }
            if (data.greetings) {
                document.getElementById('emailGreetings').value = data.greetings.join('\n');
            }
            if (data.closings) {
                document.getElementById('emailClosings').value = data.closings.join('\n\n');
            }
            if (data.devices) {
                document.getElementById('emailDevice').value = data.devices.filter(s => s).join('\n\n');
            } else {
                document.getElementById('emailDevice').value = [
                    'Odoslané z iPhone',
                    'Odoslané z iPhonu',
                    'Sent from my iPhone',
                    'Odoslané z iPadu',
                    'Odoslané z môjho iPhonu cez 5G',
                    'Odoslané zo Samsungu',
                    'Odoslané z telefónu Galaxy',
                    'Odoslané z môjho telefónu Samsung Galaxy',
                    'Odoslané zo zariadenia Huawei',
                    'Odoslané zo zariadenia Android',
                    'Odoslané z mobilu',
                    'Z mobilu',
                    'Sent from my mobile',
                ].join('\n\n');
            }
            document.getElementById('emailBody').value = data.emailBody || '';
        }
    } catch (error) {
        console.error('Error loading settings:', error);
    }
}

function splitEntries(text) {
    const trimmed = text.trim();
    if (!trimmed) return [];
    if (trimmed.includes('\n\n')) {
        return trimmed.split(/\n\s*\n/).map(s => s.trim()).filter(s => s);
    }
    return trimmed.split('\n').map(s => s.trim()).filter(s => s);
}

smtpForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const host = document.getElementById('smtpHost').value;
    const port = parseInt(document.getElementById('smtpPort').value);
    const user = document.getElementById('smtpUser').value;
    const pass = document.getElementById('smtpPass').value;
    const from = user; // Use the same email as user (avoid spam filters)
    const subjects = splitEntries(document.getElementById('emailSubjects').value);
    const greetings = splitEntries(document.getElementById('emailGreetings').value);
    const closings = splitEntries(document.getElementById('emailClosings').value);
    const devices = [...splitEntries(document.getElementById('emailDevice').value), ''];
    const emailBody = document.getElementById('emailBody').value;
    
    // Validate subjects
    if (subjects.length === 0) {
        alert('⚠️ Musíte zadať aspoň 1 predmet emailu!\n\nOdporúčame 3-10 rôznych predmetov pre lepšiu variabilitu.');
        return;
    }
    
    try {
        await setDoc(doc(db, 'settings', 'smtp'), {
            host,
            port,
            user,
            pass,
            from
        });
        
        await setDoc(doc(db, 'settings', 'email'), {
            subjects,
            greetings,
            closings,
            devices,
            emailBody
        });
        
        settingsSuccess.innerHTML = `✅ Nastavenia úspešne uložené!<br><small>Predmetov: ${subjects.length} | Oslovení: ${greetings.length} | Ukončení: ${closings.length} | Zariadení: ${devices.length}</small>`;
        settingsSuccess.classList.remove('hidden');
        setTimeout(() => {
            settingsSuccess.classList.add('hidden');
        }, 3000);
    } catch (error) {
        console.error('Error saving settings:', error);
        alert('Chyba pri ukladaní nastavení');
    }
});

// ─── Spam Score Checker ───────────────────────────────────────────────────────

const SPAM_WORDS = [
    // S diakritikou
    'zadarmo', 'akcia', 'zľava', 'zarábajte', 'zarobíte', 'zarobte',
    'investícia', 'cashback', 'výhra', 'vyhraj', 'výherca', 'cena zadarmo',
    'bezplatný', 'bezplatne', 'gratis', 'ušetríte', 'ušetrite',
    'súrne', 'ihneď', 'nezmeškajte', 'garantované', 'garantovaný',
    'limitovaná ponuka', 'len dnes', 'iba dnes', 'posledná šanca',
    'zostáva posledných', 'časovo obmedzené', 'okamžite', 'neodkladajte',
    'nečakajte', 'konajte teraz', 'rýchlo', 'rýchla akcia',
    'posledná možnosť', 'posledné kusy', 'vypredané čoskoro',
    'iba obmedzený počet', 'iba pre prvých', 'exkluzívna ponuka',
    'špeciálna ponuka vyprší', 'ponuka platí do', 'nestihli ste',
    'využite hneď', 'využite teraz', 'zaregistrujte sa ihneď',
    'obmedzená dostupnosť', 'zostatok na sklade', 'vypredaj',
    '100% úspešnosť', 'zázračné', 'bez námahy', 'bez rizika',
    'zaručený výsledok', 'najlacnejší', 'najlepší na trhu',
    'kliknite sem', 'kliknite tu', 'kupte', 'kúpte',
    'objednajte teraz', 'objednajte hneď', 'zavolajte teraz',
    // Varianty bez diakritiky (preklepy v spintaxe)
    'zlava', 'zarabajte', 'zarobite', 'investicia', 'vyhra', 'vyherca',
    'bezplatny', 'usetrите', 'usетrite', 'surne', 'ihned', 'nezmeškajte',
    'garantovane', 'garantovany', 'limitovana ponuka', 'posledna sanca',
    'casovo obmedzene', 'okamzite', 'neodkladajte',
    'posledna moznost', 'posledne kusy', 'exkluzivna ponuka',
    'vyuzite hned', 'vyuzite teraz', 'obmedzena dostupnost', 'vypredaj',
    'zaruceny vysledok', 'najlacnejsi', 'najlepsi na trhu',
    'kliknite sem', 'kupte', 'objednajte teraz', 'zavolajte teraz',
    // Anglické
    'free', 'click here', 'buy now', 'limited offer', 'guaranteed',
    'act now', 'winner', 'cash prize', 'no risk', 'order now',
];

// NALY'S ANTI-TOXIC ENGINE v1.0
const VULGAR_LIST = {
    // HARD: +20 penalizácia — email s týmto slovom by nemal nikdy odísť
    HARD: [
        // Slovenské
        'jebať', 'jebem', 'jebe', 'jebo', 'vyjebať', 'zajebať', 'zjebať', 'pojebať', 'ojebať', 'ojeb',
        'picsa', 'piča', 'pičovina', 'pičku', 'kurva', 'kurvy', 'kurvin', 'kurvička',
        'kokot', 'kokotina', 'kokoti', 'chuj', 'chujna', 'zmrd', 'zmrdi', 'hajzel',
        'vyhoniť', 'honiť', 'buzerant', 'buzerovať',
        // České
        'hujovina', 'píča', 'píčovina', 'zkurvit', 'zkurvený', 'vykurvit', 'kunda', 'kundička',
        'čurák', 'mrdka', 'mrdat', 'retard', 'retardi', 'retardovaný',
        // Anglické
        'fuck', 'fucking', 'fucked', 'fucker', 'motherfucker', 'nigger', 'faggot', 'fag',
        'bitch', 'pussy', 'cunt', 'whore', 'slut', 'cock', 'dickhead', 'asshole',
    ],
    // SOFT: +3 penalizácia — neprofesionálne, zhoršuje skóre
    SOFT: [
        // Slovenské & České
        'sračka', 'srať', 'posrať', 'zasrať', 'vyserať', 'hovno', 'hovnivý', 'hovniváč',
        'debil', 'debilný', 'debilizmus', 'kretén', 'kreténstvo', 'idiot', 'idioti', 'idiotský',
        'vole', 'vůl', 'prdel', 'odrbať', 'odrb', 'sakra', 'do prdele',
        // Anglické
        'shit', 'bullshit', 'crap', 'bastard', 'dumbass', 'jackass',
    ],
};

const TECHNICAL_CAPS = [
    'PDF', 'HTML', 'SMTP', 'CSS', 'API', 'URL', 'IT', 'SR', 'ČR',
    'EÚ', 'EU', 'NALY', 'GPS', 'DIČ', 'IČO', 'DPH', 'GDPR', 'SRO',
    'IČ', 'DPH', 'IČ DPH', 'IČDPH', 'SK', 'CZ', 'MBA', 'PhD', 'MSc',
    'PS', 'IBAN', 'BIC', 'SWIFT',
];

const SPECIAL_SYMBOLS = /[€]{2,}|[$]{2,}|[★▶▷►◄☆✓✔✗✘♦♠♣♥]{1,}|[#]{3,}/g;

function stripSpintax(text) {
    return text.replace(/\{[^}]*\}/g, 'varianta');
}

function wordCount(text) {
    return text.split(/\s+/).filter(w => w.length > 1).length;
}

function extractUrls(text) {
    return text.match(/https?:\/\/[^\s]+/gi) || [];
}

function subjectBodyOverlap(subject, body) {
    if (!subject || !body) return 0;
    const subWords = new Set(subject.toLowerCase().split(/\s+/).filter(w => w.length > 3));
    const bodyPreview = body.toLowerCase().slice(0, 150);
    if (subWords.size === 0) return 0;
    let matches = 0;
    subWords.forEach(w => { if (bodyPreview.includes(w)) matches++; });
    return matches / subWords.size;
}

function analyzeText(text, label, subjectForOverlap = null) {
    const original = stripSpintax(text);
    const lower = original.toLowerCase();
    const issues = [];
    const warnings = [];
    const good = [];
    let penalty = 0;

    // 0. Vulgárne slová — word boundary regex (\b) aby "hokejka" nespúšťala alert
    const foundHard = VULGAR_LIST.HARD.filter(w => new RegExp(`\\b${w}\\b`, 'i').test(original));
    const foundSoft = VULGAR_LIST.SOFT.filter(w => new RegExp(`\\b${w}\\b`, 'i').test(original));
    if (foundHard.length > 0) {
        issues.push(`🚨 Vulgárne slová (kritické): <strong>${foundHard.join(', ')}</strong> — email nesmie odísť`);
        penalty += 20;
    }
    if (foundSoft.length > 0) {
        warnings.push(`Neprofesionálne výrazy: <strong>${foundSoft.join(', ')}</strong> — zvážte preformulovanie`);
        penalty += 3;
    }

    // 1. Hustota spamových slov
    const totalWords = wordCount(original);
    const foundSpam = [...new Set(SPAM_WORDS.filter(w => lower.includes(w.toLowerCase())))];
    if (foundSpam.length > 0) {
        const density = foundSpam.length / Math.max(totalWords, 1);
        if (density > 0.05 || foundSpam.length >= 3) {
            issues.push(`Vysoká hustota spamových slov (${foundSpam.length} z ${totalWords}): <strong>${foundSpam.slice(0, 5).join(', ')}</strong>`);
            penalty += 3;
        } else if (foundSpam.length >= 1) {
            warnings.push(`Spamové slovo: <strong>${foundSpam.join(', ')}</strong> — zvážte nahradenie`);
            penalty += 1;
        }
    } else {
        good.push('Žiadne spamové slová');
    }

    // 2. ALL CAPS (ignoruj technické skratky)
    let capsText = original;
    TECHNICAL_CAPS.forEach(abbr => {
        capsText = capsText.replace(new RegExp(`\\b${abbr}\\b`, 'g'), '');
    });
    const capsMatches = (capsText.match(/[A-ZÁČĎÉÍĽĹŇÓÔŔŠŤÚÝŽ]{3,}/g) || []);
    if (capsMatches.length > 0) {
        issues.push(`ALL CAPS pasáže: <strong>${capsMatches.join(', ')}</strong>`);
        penalty += 2;
    } else {
        good.push('Žiadne ALL CAPS');
    }

    // 3. Výkričníky
    const exclamations = (original.match(/!/g) || []).length;
    if (exclamations > 2) {
        issues.push(`Príliš veľa výkričníkov: <strong>${exclamations}×</strong> — max 1`);
        penalty += 2;
    } else if (exclamations === 2) {
        warnings.push('Dva výkričníky — odporúčame max 1');
        penalty += 1;
    } else {
        good.push('Výkričníky v poriadku');
    }

    // 4. Kombinovaná interpunkcia
    if (/[?!]{2,}/.test(original)) {
        issues.push('Kombinovaná interpunkcia: <strong>?! alebo !?</strong>');
        penalty += 1;
    }

    // 4b. Číslo/mena + výkričník (100 €!, 50%!, 9.99$!)
    const moneyExclaim = original.match(/[\d,.]+\s*[€$£%]\s*!|[€$£]\s*[\d,.]+\s*!/g) || [];
    if (moneyExclaim.length > 0) {
        issues.push(`Mena + výkričník: <strong>${moneyExclaim.join(', ')}</strong> — typický znak agresívneho marketingu`);
        penalty += 2;
    }

    // 5. URL skracovače
    if (/bit\.ly|tinyurl|goo\.gl|t\.co/i.test(original)) {
        issues.push('Skrátená URL: <strong>bit.ly / tinyurl</strong> — použite plnú adresu webu');
        penalty += 3;
    } else {
        good.push('Žiadne skrátené URL');
    }

    // 6. Počet URL (max 1 v plain texte)
    const urls = extractUrls(original);
    const uniqueUrls = [...new Set(urls)];
    if (uniqueUrls.length > 1) {
        issues.push(`Príliš veľa odkazov: <strong>${uniqueUrls.length} URL</strong> — v prvom kontakte max 1`);
        penalty += 2;
    } else if (uniqueUrls.length === 1) {
        good.push(`1 URL odkaz — v poriadku`);
    }

    // 6b. IP adresa v URL
    if (/https?:\/\/\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/i.test(original)) {
        issues.push('IP adresa v odkaze: <strong>http://192.168...</strong> — použite doménu (napr. naly.sk)');
        penalty += 3;
    }

    // 7. Tracking parametre
    if (/utm_source|utm_medium|utm_campaign|fbclid|gclid/i.test(original)) {
        issues.push('Tracking parametre v URL: <strong>utm_source / fbclid</strong> — odstrániť');
        penalty += 2;
    }

    // 8. Dĺžka textu (Goldilocks)
    const len = original.replace(/\s+/g, ' ').trim().length;
    if (len < 100) {
        warnings.push(`Príliš krátky text: <strong>${len} znakov</strong> — odporúčame 200–800`);
        penalty += 1;
    } else if (len > 1500) {
        warnings.push(`Príliš dlhý text: <strong>${len} znakov</strong> — odporúčame max 800`);
        penalty += 1;
    } else if (len >= 200 && len <= 800) {
        good.push(`Ideálna dĺžka: ${len} znakov`);
    } else {
        good.push(`Dĺžka textu: ${len} znakov`);
    }

    // 9. Špeciálne symboly
    const symbols = original.match(SPECIAL_SYMBOLS) || [];
    if (symbols.length > 0) {
        issues.push(`Špeciálne symboly: <strong>${symbols.join(' ')}</strong>`);
        penalty += 2;
    }

    // 10. Subject-body overlap (len pre body)
    if (subjectForOverlap) {
        const overlap = subjectBodyOverlap(subjectForOverlap, original);
        if (overlap > 0.7) {
            warnings.push(`Predmet a telo emailu sú príliš podobné (<strong>${Math.round(overlap * 100)}% zhoda</strong>) — typický znak bota`);
            penalty += 2;
        } else if (overlap > 0.5) {
            warnings.push(`Predmet a telo emailu sa čiastočne opakujú (<strong>${Math.round(overlap * 100)}% zhoda</strong>)`);
            penalty += 1;
        }
    }

    const score = Math.max(0, 10 - penalty);
    const scoreColor = score >= 8 ? 'text-green-600' : score >= 5 ? 'text-yellow-600' : 'text-red-600';
    const scoreBg   = score >= 8 ? 'bg-green-50 border-green-200' : score >= 5 ? 'bg-yellow-50 border-yellow-200' : 'bg-red-50 border-red-200';
    const scoreBorder = score >= 8 ? 'border-green-200' : score >= 5 ? 'border-yellow-200' : 'border-red-200';
    const scoreLabel = score >= 8 ? '✅ Nízke riziko' : score >= 5 ? '⚠️ Stredné riziko' : '🛑 Vysoké riziko';

    let html = `
        <div class="border ${scoreBorder} rounded-xl overflow-hidden">
            <div class="flex items-center justify-between px-4 py-3 ${scoreBg} border-b ${scoreBorder}">
                <span class="text-sm font-bold text-gray-700">${label}</span>
                <div class="flex items-center gap-2">
                    <span class="text-lg font-bold ${scoreColor}">${score}/10</span>
                    <span class="text-xs font-semibold ${scoreColor}">${scoreLabel}</span>
                </div>
            </div>
            <div class="px-4 py-3 space-y-1 bg-white">
    `;
    issues.forEach(i  => { html += `<p class="text-xs text-red-700">❌ ${i}</p>`; });
    warnings.forEach(w => { html += `<p class="text-xs text-yellow-700">⚠️ ${w}</p>`; });
    good.forEach(g    => { html += `<p class="text-xs text-green-700">✅ ${g}</p>`; });
    html += `</div></div>`;
    return { html, score };
}

let spamCheckPassed = true;

function updateSaveButton() {
    const saveBtn = document.querySelector('#smtpForm button[type="submit"]');
    const existingWarning = document.getElementById('spamSaveWarning');
    if (existingWarning) existingWarning.remove();

    if (!spamCheckPassed) {
        saveBtn.disabled = true;
        saveBtn.classList.add('opacity-50', 'cursor-not-allowed');
        const warning = document.createElement('p');
        warning.id = 'spamSaveWarning';
        warning.className = 'text-center text-sm text-red-600 font-medium';
        warning.textContent = '🛑 Email obsahuje zakázané slová. Oprav ho pred uložením.';
        saveBtn.parentNode.insertBefore(warning, saveBtn);
    } else {
        saveBtn.disabled = false;
        saveBtn.classList.remove('opacity-50', 'cursor-not-allowed');
    }
}

document.getElementById('spamCheckBtn').addEventListener('click', () => {
    const subjects = splitEntries(document.getElementById('emailSubjects').value);
    const body = document.getElementById('emailBody').value.trim();

    if (!subjects.length && !body) {
        alert('Najprv vyplňte predmety alebo telo emailu.');
        return;
    }

    const subjectText = subjects.join(' | ');
    const subjectResult = subjectText
        ? analyzeText(subjectText, '📋 Predmety emailov')
        : { html: '<p class="text-xs text-gray-400 px-2">Žiadne predmety na kontrolu.</p>', score: 10 };

    const bodyResult = body
        ? analyzeText(body, '✉️ Telo emailu', subjectText)
        : { html: '<p class="text-xs text-gray-400 px-2">Žiadne telo emailu na kontrolu.</p>', score: 10 };

    document.getElementById('spamSubjectResult').innerHTML = subjectResult.html;
    document.getElementById('spamBodyResult').innerHTML = bodyResult.html;
    document.getElementById('spamResults').classList.remove('hidden');

    // Blokovanie uloženia ak skóre = 0 (HARD slová alebo extrémne spam)
    spamCheckPassed = subjectResult.score > 0 && bodyResult.score > 0;
    updateSaveButton();
});

// ─────────────────────────────────────────────
// BLACKLIST
// ─────────────────────────────────────────────

let allBlacklistEntries = [];
let currentFilter = 'all';

async function loadBlacklist() {
    const tbody = document.getElementById('blacklistTable');
    tbody.innerHTML = `<tr><td colspan="5" class="px-6 py-8 text-center text-gray-500">
        <div class="loader mx-auto"></div><p class="mt-2">Načítavam...</p></td></tr>`;

    try {
        const snap = await getDocs(query(collection(db, 'blacklist'), orderBy('addedAt', 'desc')));
        allBlacklistEntries = snap.docs.map(d => ({ id: d.id, ...d.data() }));
        renderBlacklist();
    } catch (err) {
        console.error('Blacklist load error:', err);
        tbody.innerHTML = `<tr><td colspan="5" class="px-6 py-8 text-center text-red-500">Chyba pri načítaní blacklistu.</td></tr>`;
    }
}

function renderBlacklist() {
    const tbody = document.getElementById('blacklistTable');
    const countEl = document.getElementById('blacklistCount');

    let entries = allBlacklistEntries;
    if (currentFilter === 'email') {
        entries = entries.filter(e => e.type === 'email');
    } else if (currentFilter === 'domain') {
        entries = entries.filter(e => e.type === 'domain');
    } else if (currentFilter === 'hard_bounce') {
        entries = entries.filter(e => e.type === 'hard_bounce');
    }

    countEl.textContent = `(${entries.length})`;

    if (entries.length === 0) {
        tbody.innerHTML = `<tr><td colspan="5" class="px-6 py-10 text-center text-gray-400 text-sm">
            Žiadne záznamy v tejto kategórii.</td></tr>`;
        return;
    }

    tbody.innerHTML = entries.map(e => {
        const date = e.addedAt ? new Date(e.addedAt.seconds * 1000).toLocaleDateString('sk-SK') : '—';
        const typeBadge = e.type === 'hard_bounce'
            ? '<span class="px-2 py-0.5 text-xs font-medium bg-red-100 text-red-700 rounded-full">Neplatná adresa</span>'
            : e.type === 'domain'
                ? '<span class="px-2 py-0.5 text-xs font-medium bg-purple-100 text-purple-700 rounded-full">Doména</span>'
                : '<span class="px-2 py-0.5 text-xs font-medium bg-gray-100 text-gray-700 rounded-full">Email</span>';
        return `
        <tr class="hover:bg-gray-50 transition">
            <td class="px-6 py-3 text-sm font-medium text-gray-900">${e.value}</td>
            <td class="px-6 py-3">${typeBadge}</td>
            <td class="px-6 py-3 text-sm text-gray-600">${e.reason || '—'}</td>
            <td class="px-6 py-3 text-sm text-gray-500">${date}</td>
            <td class="px-6 py-3">
                <button onclick="deleteBlacklistEntry('${e.id}')"
                    class="text-red-500 hover:text-red-700 text-xs font-medium transition">
                    Zmazať
                </button>
            </td>
        </tr>`;
    }).join('');
}

window.filterBlacklist = function(type) {
    currentFilter = type;

    document.querySelectorAll('.blacklist-filter').forEach(btn => {
        btn.classList.remove('bg-primary', 'text-white');
        btn.classList.add('bg-gray-100', 'text-gray-600');
    });
    const activeBtn = document.getElementById(
        type === 'all' ? 'filterAll' :
        type === 'email' ? 'filterEmail' :
        type === 'domain' ? 'filterDomain' : 'filterBounce'
    );
    if (activeBtn) {
        activeBtn.classList.add('bg-primary', 'text-white');
        activeBtn.classList.remove('bg-gray-100', 'text-gray-600');
    }

    renderBlacklist();
};

window.deleteBlacklistEntry = async function(id) {
    if (!confirm('Naozaj chceš odstrániť tento záznam z blacklistu?')) return;
    try {
        await deleteDoc(doc(db, 'blacklist', id));
        allBlacklistEntries = allBlacklistEntries.filter(e => e.id !== id);
        renderBlacklist();
    } catch (err) {
        console.error('Delete blacklist error:', err);
        alert('Chyba pri mazaní záznamu.');
    }
};

// Jednorazové/dočasné emaily — nikdy za nimi nestojí reálna osoba
const TOXIC_DOMAINS = [
    'mailinator.com', '10minutemail.com', 'guerrillamail.com', 'temp-mail.org',
    'trashmail.com', 'sharklasers.com', 'getairmail.com', 'yopmail.com',
    'dispostable.com', 'spam4.me', 'maildrop.cc', 'mail-tester.com',
    'throwam.com', 'spamgourmet.com', 'fakeinbox.com', 'mailnull.com',
    'spamherelots.com', 'trashmail.me', 'tempmail.com', 'throwam.com',
];

function isToxicDomain(email) {
    const domain = (email.split('@')[1] || '').toLowerCase().trim();
    return TOXIC_DOMAINS.includes(domain);
}

const PROTECTED_DOMAINS = [
    // Globálni giganti
    '@gmail.com', '@googlemail.com',
    '@outlook.com', '@hotmail.com', '@live.com', '@msn.com',
    '@icloud.com', '@me.com', '@mac.com',
    '@yahoo.com', '@ymail.com', '@rocketmail.com',
    '@aol.com', '@aim.com',
    // Slovenskí poskytovatelia
    '@zoznam.sk', '@azet.sk', '@centrum.sk', '@atlas.sk',
    '@pobox.sk', '@post.sk', '@stonline.sk',
    '@orange.sk', '@telekom.sk', '@upc.sk',
    // Českí poskytovatelia
    '@seznam.cz', '@email.cz', '@post.cz', '@volny.cz',
    '@centrum.cz', '@atlas.cz', '@tiscali.cz', '@quick.cz',
    // Privacy a iní svetoví hráči
    '@proton.me', '@protonmail.com', '@pm.me',
    '@tutanota.com', '@tuta.io', '@tuta.com',
    '@mail.com', '@email.com',
    '@gmx.com', '@gmx.net', '@gmx.at', '@gmx.ch',
    '@fastmail.com', '@fastmail.fm',
    '@yandex.com', '@yandex.ru',
];

async function addToBlacklist(value, reason, type) {
    const trimmed = value.trim().toLowerCase();
    if (!trimmed) return;

    const isDomain = trimmed.startsWith('@');
    const entryType = type || (isDomain ? 'domain' : 'email');

    if (isDomain && PROTECTED_DOMAINS.includes(trimmed)) {
        alert(`⚠️ Túto doménu nemôžeš zablokovať celú!\n\n"${trimmed}" používajú státisíce ľudí. EMIL by nemal komu písať.\n\nAk chceš zablokovať konkrétnu osobu, pridaj jej celý email napr. jan@gmail.com.`);
        return;
    }

    const existing = allBlacklistEntries.find(e => e.id === trimmed);
    if (existing) {
        alert('Tento záznam je už v blackliste.');
        return;
    }

    try {
        // Doc ID = email alebo @doména → O(1) lookup, žiadne duplicity
        await setDoc(doc(db, 'blacklist', trimmed), {
            value: trimmed,
            type: entryType,
            reason: reason || 'Manuálne',
            addedAt: serverTimestamp(),
        });
        allBlacklistEntries.unshift({ id: trimmed, value: trimmed, type: entryType, reason: reason || 'Manuálne', addedAt: { seconds: Date.now() / 1000 } });
        renderBlacklist();
    } catch (err) {
        console.error('Add blacklist error:', err);
        alert('Chyba pri pridávaní záznamu.');
    }
}

document.getElementById('blacklistAddBtn').addEventListener('click', async () => {
    const input = document.getElementById('blacklistInput').value.trim();
    const reason = document.getElementById('blacklistReason').value.trim() || 'Manuálne';
    if (!input) {
        alert('Zadaj email alebo doménu (napr. @firma.sk).');
        return;
    }
    await addToBlacklist(input, reason);
    document.getElementById('blacklistInput').value = '';
    document.getElementById('blacklistReason').value = '';
});

document.getElementById('blacklistInput').addEventListener('keydown', async (e) => {
    if (e.key === 'Enter') {
        e.preventDefault();
        document.getElementById('blacklistAddBtn').click();
    }
});
